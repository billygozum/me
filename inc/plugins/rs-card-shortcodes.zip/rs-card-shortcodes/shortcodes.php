<?php
/*
Plugin Name: Shortcodes
Description: Declares a plugin that will create a custom Shortcodes for Rs Card theme.
Version: 1.0
*/


// One/half
add_shortcode('wrapper', 'one_half_wrapper');
function one_half_wrapper($atts, $cont = null) {

    $str = "<div class='row'>";
    $str .= do_shortcode($cont);
    $str .= '</div>';
    return $str;
}
add_shortcode('one_half', 'one_half');
function one_half($atts, $cont = null) {
    $str = '';
    $str .= "<div class='col-sm-6'>";
    $str .= do_shortcode($cont);
    $str .= "</div>";
    return $str;
}
add_shortcode('one_third', 'one_third');
function one_third($atts, $cont = null) {

    $str = '';
    $str .= "<div class='col-sm-4'>";
    $str .= do_shortcode($cont);
    $str .= "</div>";
    return $str;
}
add_shortcode('one_fourth', 'one_fourth');
function one_fourth($atts, $cont = null) {
    $str = '';
    $str .= "<div class='col-sm-3'>";
    $str .= do_shortcode($cont);
    $str .= "</div>";
    return $str;
}

// Button
add_shortcode('rs_card_button', 'rs_card_button');
function rs_card_button( $atts ) {
    extract( shortcode_atts( array(
        'button_text' => '',
        'button_link'   => '#',
        'target'   => '_blank',
    ), $atts ) );
	if($button_text || $button_link):
		$out = '<p><a class="btn btn-lg btn-border ripple" target="'.$target.'" href="'.$button_link.'">'.$button_text.'</a></p>';
	endif;

    return $out;
}

add_action('media_buttons','add_sc_select',11);

function add_sc_select(){
    global $shortcode_tags;
    echo '&nbsp;<select class="sc_select"><option value="">Select Shortcode</option>';
    $shortcodes_list .= '<option value="'."[wrapper][one_half]
<h3>ONE HALF</h3>
Established fact that a reader will be distracted by the readable content of a page when lookingt its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters.[/one_half][one_half]
<h3>ONE HALF</h3>
Established fact that a reader will be distracted by the readable content of a page when lookingt its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters.[/one_half][/wrapper]".'">One Half</option>';
    $shortcodes_list .= '<option value="'."[wrapper][one_third]
<h3>ONE THIRD</h3>
Established fact that a reader will be distracted by the readable content of a page when lookingt its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters.[/one_third][one_third]
<h3>ONE THIRD</h3>
Established fact that a reader will be distracted by the readable content of a page when lookingt its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters.[/one_third][one_third]
<h3>ONE THIRD</h3>
Established fact that a reader will be distracted by the readable content of a page when lookingt its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters.[/one_third][/wrapper]".'">One Third</option>';
    $shortcodes_list .= '<option value="'."[wrapper][one_fourth]
<h3>ONE FOURTH</h3>
Established fact that a reader will be distracted by the readable content of a page when lookingt its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters.[/one_fourth][one_fourth]
<h3>ONE FOURTH</h3>
Established fact that a reader will be distracted by the readable content of a page when lookingt its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters.[/one_fourth][one_fourth]
<h3>ONE FOURTH</h3>
Established fact that a reader will be distracted by the readable content of a page when lookingt its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters.[/one_fourth][one_fourth]
<h3>ONE FOURTH</h3>
Established fact that a reader will be distracted by the readable content of a page when lookingt its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters.[/one_fourth][/wrapper]".'">One Fourth</option>';
	$shortcodes_list .= '<option value="'."[rs_card_button button_text='Download' button_link='#' target='_blank']".'">Button</option>';
    echo $shortcodes_list;
    echo '</select>';
}
add_action('admin_head', 'button_js');
function button_js() {
    echo '<script type="text/javascript">
			jQuery(document).ready(function(){
			   jQuery(".sc_select").change(function() {
				var val =jQuery(this).val();
					 send_to_editor(val);
						  return false;
				});
			});
		</script>';
}

add_filter("the_content", "the_content_filter");
function the_content_filter($content) {
    // array of custom shortcodes requiring the fix
    $block = join("|",array("wrapper","one_half","one_third","one_fourth"));
    // opening tag
    $rep = preg_replace("/(<p>)?\[($block)(\s[^\]]+)?\](<\/p>|<br \/>)?/","[$2$3]",$content);

    // closing tag
    $rep = preg_replace("/(<p>)?\[\/($block)](<\/p>|<br \/>)?/","[/$2]",$rep);
    return $rep;
}